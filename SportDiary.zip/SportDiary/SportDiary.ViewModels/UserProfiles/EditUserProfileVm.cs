﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace SportDiary.ViewModels.UserProfiles
{
    public class EditUserProfileVm
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [Range(10, 100)]
        public int Age { get; set; }

        [Required]
        public string Gender { get; set; } = string.Empty; // Male/Female

        [Range(30, 300)]
        public double StartWeightKg { get; set; }

        [Range(100, 250)]
        public int HeightCm { get; set; }

        [Required]
        public string ActivityLevel { get; set; } = string.Empty; // Low/Medium/High

        // ✅ само за dropdown
        public List<SelectListItem> ActivityOptions { get; set; } = new();
    }
}
