﻿using System.ComponentModel.DataAnnotations;
using static SportDiary.GCommon.ValidationConstants;

namespace SportDiary.ViewModels.UserProfile
{
    public class EditUserProfileVm
    {
        [Required]
        [StringLength(NameMaxLength, MinimumLength = NameMinLength)]
        public string Name { get; set; } = string.Empty;

        [Range(AgeMin, AgeMax)]
        public int Age { get; set; }
    }
}
