﻿namespace SportDiary.ViewModels.UserProfiles
{
    public class UserProfileAllViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public int Age { get; set; }
    }
}
