﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using SportDiary.Data.Models;
using SportDiary.Services.Core.Interfaces;
using SportDiary.ViewModels.UserProfile;

namespace SportDiary.Controllers
{
    [Authorize]
    public class UserProfilesController : Controller
    {
        private readonly IUserProfileService _profileService;
        private readonly UserManager<ApplicationUser> _userManager;

        public UserProfilesController(
            IUserProfileService profileService,
            UserManager<ApplicationUser> userManager)
        {
            _profileService = profileService;
            _userManager = userManager;
        }

        private string GetUserId() => _userManager.GetUserId(User)!;

        // GET: /UserProfiles/Me  (линк от менюто)
        [HttpGet]
        public IActionResult Me()
        {
            return RedirectToAction(nameof(Index));
        }

        // GET: /UserProfiles
        // "Моят профил" (кратък изглед)
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var userId = GetUserId();
            var profile = await _profileService.GetMyProfileAsync(userId);
            return View(profile);
        }

        // GET: /UserProfiles/Details
        // "Моят профил" + дневници (по-пълен изглед)
        [HttpGet]
        public async Task<IActionResult> Details()
        {
            var userId = GetUserId();
            var profile = await _profileService.GetMyProfileWithDiariesAsync(userId);
            return View(profile);
        }

        // GET: /UserProfiles/Edit
        [HttpGet]
        public async Task<IActionResult> Edit()
        {
            var userId = GetUserId();
            var profile = await _profileService.GetMyProfileAsync(userId);

            var vm = new EditUserProfileVm
            {
                Name = profile.Name,
                Age = profile.Age
            };

            return View(vm);
        }

        // POST: /UserProfiles/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(EditUserProfileVm vm)
        {
            if (!ModelState.IsValid)
                return View(vm);

            var userId = GetUserId();
            await _profileService.UpdateMyProfileAsync(userId, vm.Name, vm.Age);

            return RedirectToAction(nameof(Details));
        }
    }
}
