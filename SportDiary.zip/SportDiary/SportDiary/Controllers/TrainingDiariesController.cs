using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using SportDiary.Data.Models;
using SportDiary.Services.Core.Interfaces;

namespace SportDiary.Controllers
{
    [Authorize]
    public class TrainingDiariesController : Controller
    {
        private readonly ITrainingDiaryService _diaryService;
        private readonly IUserProfileService _profileService;
        private readonly UserManager<ApplicationUser> _userManager;

        public TrainingDiariesController(
            ITrainingDiaryService diaryService,
            IUserProfileService profileService,
            UserManager<ApplicationUser> userManager)
        {
            _diaryService = diaryService;
            _profileService = profileService;
            _userManager = userManager;
        }

        private string GetUserId() => _userManager.GetUserId(User)!;

        private async Task<int> GetMyProfileIdAsync()
        {
            var userId = GetUserId();
            var profile = await _profileService.GetMyProfileAsync(userId);
            return profile.Id;
        }

        public async Task<IActionResult> Index()
        {
            var userProfileId = await GetMyProfileIdAsync();
            var diaries = await _diaryService.GetMyDiariesAsync(userProfileId);
            return View(diaries);
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var userProfileId = await GetMyProfileIdAsync();
            var diary = await _diaryService.GetMyDiaryDetailsAsync(id.Value, userProfileId);

            if (diary == null) return NotFound();

            return View(diary);
        }

        // GET
        public IActionResult Create()
        {
            return View();
        }

        // POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Date,Notes")] TrainingDiary trainingDiary)
        {
            var userProfileId = await GetMyProfileIdAsync();

            trainingDiary.UserProfileId = userProfileId;

            if (!ModelState.IsValid)
                return View(trainingDiary);

            var exists = await _diaryService.DiaryExistsForDateAsync(userProfileId, trainingDiary.Date);
            if (exists)
            {
                ModelState.AddModelError(nameof(trainingDiary.Date), "Вече има дневник за тази дата.");
                return View(trainingDiary);
            }

            await _diaryService.CreateAsync(trainingDiary);
            return RedirectToAction(nameof(Index));
        }

        // GET
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var userProfileId = await GetMyProfileIdAsync();
            var diary = await _diaryService.GetMyDiaryForEditAsync(id.Value, userProfileId);

            if (diary == null) return NotFound();

            return View(diary);
        }

        // POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Date,Notes")] TrainingDiary trainingDiary)
        {
            if (id != trainingDiary.Id) return NotFound();

            var userProfileId = await GetMyProfileIdAsync();

            trainingDiary.UserProfileId = userProfileId;

            if (!ModelState.IsValid)
                return View(trainingDiary);

            var exists = await _diaryService.DiaryExistsForDateAsync(
                userProfileId, trainingDiary.Date, excludeDiaryId: trainingDiary.Id);

            if (exists)
            {
                ModelState.AddModelError(nameof(trainingDiary.Date), "Вече има дневник за тази дата.");
                return View(trainingDiary);
            }

            var updated = await _diaryService.UpdateAsync(
                diaryId: trainingDiary.Id,
                userProfileId: userProfileId,
                date: trainingDiary.Date,
                notes: trainingDiary.Notes
            );

            if (!updated) return NotFound();

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var userProfileId = await GetMyProfileIdAsync();
            var diary = await _diaryService.GetMyDiaryDetailsAsync(id.Value, userProfileId);

            if (diary == null) return NotFound();

            return View(diary);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var userProfileId = await GetMyProfileIdAsync();

            var deleted = await _diaryService.DeleteAsync(id, userProfileId);
            if (!deleted) return NotFound();

            return RedirectToAction(nameof(Index));
        }
    }
}
