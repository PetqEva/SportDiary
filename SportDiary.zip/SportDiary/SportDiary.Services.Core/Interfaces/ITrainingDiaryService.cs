﻿using SportDiary.Data.Models;

namespace SportDiary.Services.Core.Interfaces
{
    public interface ITrainingDiaryService
    {
        Task<List<TrainingDiary>> GetMyDiariesAsync(int userProfileId);
        Task<TrainingDiary?> GetMyDiaryDetailsAsync(int diaryId, int userProfileId);
        Task<TrainingDiary?> GetMyDiaryForEditAsync(int diaryId, int userProfileId);

        Task<bool> DiaryExistsForDateAsync(int userProfileId, DateTime date, int? excludeDiaryId = null);

        Task<int> CreateAsync(TrainingDiary diary);
        Task<bool> UpdateAsync(int diaryId, int userProfileId, DateTime date, string? notes);
        Task<bool> DeleteAsync(int diaryId, int userProfileId);
    }
}
