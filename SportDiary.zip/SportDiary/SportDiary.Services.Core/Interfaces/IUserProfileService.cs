﻿using SportDiary.Data.Models;

namespace SportDiary.Services.Core.Interfaces
{
    public interface IUserProfileService
    {
        Task<UserProfile> GetMyProfileAsync(string userId);
        Task<UserProfile> GetMyProfileWithDiariesAsync(string userId);

        Task CreateMyProfileAsync(
            string userId,
            string name,
            int age,
            string gender,
            double startWeightKg,
            int heightCm,
            string activityLevel);

        Task UpdateMyProfileAsync(
            string userId,
            string name,
            int age,
            string gender,
            double startWeightKg,
            int heightCm,
            string activityLevel);

        Task DeleteMyProfileAsync(string userId);
    }
}

