﻿using SportDiary.Data.Models;

namespace SportDiary.Services.Core.Interfaces
{
    public interface IUserProfileService
    {
        Task<UserProfile> GetMyProfileAsync(string userId);
        Task<UserProfile> GetMyProfileWithDiariesAsync(string userId);
        Task UpdateMyProfileAsync(string userId, string name, int age);
    }
}
