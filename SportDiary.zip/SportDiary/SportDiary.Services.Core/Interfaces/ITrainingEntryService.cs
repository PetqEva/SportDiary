﻿using SportDiary.Data.Models;

namespace SportDiary.Services.Core.Interfaces
{
    public interface ITrainingEntryService
    {
        Task<List<TrainingEntry>> GetMyEntriesAsync(int userProfileId);
        Task<TrainingEntry?> GetMyEntryDetailsAsync(int entryId, int userProfileId);
        Task<TrainingEntry?> GetMyEntryForEditAsync(int entryId, int userProfileId);

        Task<bool> DiaryBelongsToMeAsync(int diaryId, int userProfileId);

        Task<int> CreateAsync(TrainingEntry entry, int userProfileId);
        Task<bool> UpdateAsync(TrainingEntry form, int userProfileId);
        Task<bool> DeleteAsync(int entryId, int userProfileId);

        Task<List<(int Id, string Text)>> GetMyDiarySelectItemsAsync(int userProfileId);
    }
}
