﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SportDiary.Data.Models
{
    public class UserProfile
    {
        public int Id { get; set; }

        // ✅ това го иска старият ти код
        [Required]
        public string IdentityUserId { get; set; } = string.Empty;

        // ✅ навигация към ApplicationUser (или IdentityUser)
        [ForeignKey(nameof(IdentityUserId))]
        public ApplicationUser IdentityUser { get; set; } = null!;

        // ✅ ако проектът ти го ползва
        public ICollection<TrainingDiary> TrainingDiaries { get; set; } = new List<TrainingDiary>();

        // ✅ новите полета
        [Required, MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [Range(10, 100)]
        public int Age { get; set; }

        [Required]
        public string Gender { get; set; } = string.Empty;   // "Male"/"Female"

        [Range(30, 300)]
        public double StartWeightKg { get; set; }

        [Range(100, 250)]
        public int HeightCm { get; set; }

        [Required]
        public string ActivityLevel { get; set; } = string.Empty; // "Low/Medium/High"
    }
}
