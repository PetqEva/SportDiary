﻿using Microsoft.EntityFrameworkCore;
using SportDiary.Data;
using SportDiary.Data.Models;
using SportDiary.Services.Core.Interfaces;

namespace SportDiary.Services.Implementations
{
    public class TrainingDiaryService : ITrainingDiaryService
    {
        private readonly AppDbContext _context;

        public TrainingDiaryService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<TrainingDiary>> GetMyDiariesAsync(int userProfileId)
        {
            return await _context.TrainingDiaries
                .Where(d => d.UserProfileId == userProfileId)
                .OrderByDescending(d => d.Date)
                .AsNoTracking()
                .ToListAsync();
        }

        public async Task<TrainingDiary?> GetMyDiaryDetailsAsync(int diaryId, int userProfileId)
        {
            return await _context.TrainingDiaries
                .Include(d => d.TrainingEntries)
                .FirstOrDefaultAsync(d => d.Id == diaryId && d.UserProfileId == userProfileId);
        }

        public async Task<TrainingDiary?> GetMyDiaryForEditAsync(int diaryId, int userProfileId)
        {
            return await _context.TrainingDiaries
                .FirstOrDefaultAsync(d => d.Id == diaryId && d.UserProfileId == userProfileId);
        }

        public async Task<bool> DiaryExistsForDateAsync(int userProfileId, DateTime date, int? excludeDiaryId = null)
        {
            return await _context.TrainingDiaries.AnyAsync(d =>
                d.UserProfileId == userProfileId &&
                d.Date.Date == date.Date &&
                (!excludeDiaryId.HasValue || d.Id != excludeDiaryId.Value));
        }

        public async Task<int> CreateAsync(TrainingDiary diary)
        {
            _context.TrainingDiaries.Add(diary);
            await _context.SaveChangesAsync();
            return diary.Id;
        }

        public async Task<bool> UpdateAsync(int diaryId, int userProfileId, DateTime date, string? notes)
        {
            var diary = await _context.TrainingDiaries
                .FirstOrDefaultAsync(d => d.Id == diaryId && d.UserProfileId == userProfileId);

            if (diary == null) return false;

            diary.Date = date;
            diary.Notes = notes;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAsync(int diaryId, int userProfileId)
        {
            var diary = await _context.TrainingDiaries
                .Include(d => d.TrainingEntries)
                .FirstOrDefaultAsync(d => d.Id == diaryId && d.UserProfileId == userProfileId);

            if (diary == null) return false;

            _context.TrainingDiaries.Remove(diary);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
