﻿using Microsoft.EntityFrameworkCore;
using SportDiary.Data;                // AppDbContext
using SportDiary.Data.Models;          // UserProfile, TrainingDiary
using SportDiary.Services.Core.Interfaces;
using System;

namespace SportDiary.Services.Implementations
{
    public class UserProfileService : IUserProfileService
    {
        private readonly AppDbContext _context;

        public UserProfileService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<UserProfile> GetMyProfileAsync(string userId)
        {
            var profile = await _context.UserProfiles
                .FirstOrDefaultAsync(p => p.IdentityUserId == userId);

            if (profile == null)
            {
                // Ако при теб профилът се създава при регистрация – това не трябва да се случва.
                // Ако НЕ се създава автоматично, кажи и ще го направим да се създава тук.
                throw new InvalidOperationException("UserProfile not found for current user.");
            }

            return profile;
        }

        public async Task<UserProfile> GetMyProfileWithDiariesAsync(string userId)
        {
            var profile = await _context.UserProfiles
                .Include(p => p.TrainingDiaries)
                .FirstOrDefaultAsync(p => p.IdentityUserId == userId);

            if (profile == null)
                throw new InvalidOperationException("UserProfile not found for current user.");

            return profile;
        }

        public async Task UpdateMyProfileAsync(string userId, string name, int age)
        {
            var profile = await _context.UserProfiles
                .FirstOrDefaultAsync(p => p.IdentityUserId == userId);

            if (profile == null)
                throw new InvalidOperationException("UserProfile not found for current user.");

            profile.Name = name;
            profile.Age = age;

            await _context.SaveChangesAsync();
        }
    }
}
