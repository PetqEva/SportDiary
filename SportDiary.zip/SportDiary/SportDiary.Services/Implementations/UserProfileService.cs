﻿using Microsoft.EntityFrameworkCore;
using SportDiary.Data;
using SportDiary.Data.Models;
using SportDiary.Services.Core.Interfaces;

namespace SportDiary.Services.Implementations
{
    public class UserProfileService : IUserProfileService
    {
        private readonly AppDbContext _context;

        public UserProfileService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<UserProfile> GetMyProfileAsync(string userId)
        {
            var profile = await _context.UserProfiles
                .FirstOrDefaultAsync(p => p.IdentityUserId == userId);

            if (profile == null)
                throw new InvalidOperationException("UserProfile not found for current user.");

            return profile;
        }

        public async Task<UserProfile> GetMyProfileWithDiariesAsync(string userId)
        {
            var profile = await _context.UserProfiles
                .Include(p => p.TrainingDiaries)
                .FirstOrDefaultAsync(p => p.IdentityUserId == userId);

            if (profile == null)
                throw new InvalidOperationException("UserProfile not found for current user.");

            return profile;
        }

        public async Task CreateMyProfileAsync(
            string userId,
            string name,
            int age,
            string gender,
            double startWeightKg,
            int heightCm,
            string activityLevel)
        {
            var exists = await _context.UserProfiles.AnyAsync(p => p.IdentityUserId == userId);
            if (exists)
                throw new InvalidOperationException("UserProfile already exists for current user.");

            var profile = new UserProfile
            {
                IdentityUserId = userId,
                Name = name,
                Age = age,
                Gender = gender,
                StartWeightKg = startWeightKg,
                HeightCm = heightCm,
                ActivityLevel = activityLevel
            };

            _context.UserProfiles.Add(profile);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateMyProfileAsync(
            string userId,
            string name,
            int age,
            string gender,
            double startWeightKg,
            int heightCm,
            string activityLevel)
        {
            var profile = await _context.UserProfiles
                .FirstOrDefaultAsync(p => p.IdentityUserId == userId);

            if (profile == null)
                throw new InvalidOperationException("UserProfile not found for current user.");

            profile.Name = name;
            profile.Age = age;
            profile.Gender = gender;
            profile.StartWeightKg = startWeightKg;
            profile.HeightCm = heightCm;
            profile.ActivityLevel = activityLevel;

            await _context.SaveChangesAsync();
        }

        public async Task DeleteMyProfileAsync(string userId)
        {
            var profile = await _context.UserProfiles
                .Include(p => p.TrainingDiaries)
                .FirstOrDefaultAsync(p => p.IdentityUserId == userId);

            if (profile == null)
                return;

            if (profile.TrainingDiaries?.Any() == true)
                _context.TrainingDiaries.RemoveRange(profile.TrainingDiaries);

            _context.UserProfiles.Remove(profile);
            await _context.SaveChangesAsync();
        }

    }
}
