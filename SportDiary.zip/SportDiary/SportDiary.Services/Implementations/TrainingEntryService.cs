﻿using Microsoft.EntityFrameworkCore;
using SportDiary.Data;
using SportDiary.Data.Models;
using SportDiary.Services.Core.Interfaces;

namespace SportDiary.Services.Implementations
{
    public class TrainingEntryService : ITrainingEntryService
    {
        private readonly AppDbContext _context;

        public TrainingEntryService(AppDbContext context)
        {
            _context = context;
        }

        // READ: всички мои записи (за Index)
        public async Task<List<TrainingEntry>> GetMyEntriesAsync(int userProfileId)
        {
            return await _context.TrainingEntries
                .AsNoTracking()
                .Include(e => e.TrainingDiary)
                .Where(e => e.TrainingDiary != null && e.TrainingDiary.UserProfileId == userProfileId)
                .OrderByDescending(e => e.TrainingDiary!.Date)
                .ThenByDescending(e => e.Id)
                .ToListAsync();
        }

        // READ: детайли
        public async Task<TrainingEntry?> GetMyEntryDetailsAsync(int entryId, int userProfileId)
        {
            return await _context.TrainingEntries
                .AsNoTracking()
                .Include(e => e.TrainingDiary)
                .FirstOrDefaultAsync(e =>
                    e.Id == entryId &&
                    e.TrainingDiary != null &&
                    e.TrainingDiary.UserProfileId == userProfileId);
        }

        // READ: за Edit форма
        public async Task<TrainingEntry?> GetMyEntryForEditAsync(int entryId, int userProfileId)
        {
            // за edit ти трябва TrainingDiaryId + полета; include не е задължителен, но не пречи
            return await _context.TrainingEntries
                .AsNoTracking()
                .FirstOrDefaultAsync(e =>
                    e.Id == entryId &&
                    _context.TrainingDiaries.Any(d => d.Id == e.TrainingDiaryId && d.UserProfileId == userProfileId));
        }

        // OWNERSHIP: дневникът мой ли е
        public async Task<bool> DiaryBelongsToMeAsync(int diaryId, int userProfileId)
        {
            return await _context.TrainingDiaries
                .AsNoTracking()
                .AnyAsync(d => d.Id == diaryId && d.UserProfileId == userProfileId);
        }

        // CREATE
        public async Task<int> CreateAsync(TrainingEntry entry, int userProfileId)
        {
            // ownership
            var diaryIsMine = await DiaryBelongsToMeAsync(entry.TrainingDiaryId, userProfileId);
            if (!diaryIsMine)
                throw new UnauthorizedAccessException("Diary does not belong to the current user.");

            // normalize
            entry.SportName = (entry.SportName ?? string.Empty).Trim();

            _context.TrainingEntries.Add(entry);
            await _context.SaveChangesAsync();
            return entry.Id;
        }

        // UPDATE
        public async Task<bool> UpdateAsync(TrainingEntry form, int userProfileId)
        {
            // взимаме записа само ако е мой (ownership през дневника)
            var entry = await _context.TrainingEntries
                .FirstOrDefaultAsync(e =>
                    e.Id == form.Id &&
                    _context.TrainingDiaries.Any(d => d.Id == e.TrainingDiaryId && d.UserProfileId == userProfileId));

            if (entry == null) return false;

            // ако се сменя дневникът – пак ownership
            if (entry.TrainingDiaryId != form.TrainingDiaryId)
            {
                var diaryIsMine = await DiaryBelongsToMeAsync(form.TrainingDiaryId, userProfileId);
                if (!diaryIsMine) return false;

                entry.TrainingDiaryId = form.TrainingDiaryId;
            }

            entry.SportName = (form.SportName ?? string.Empty).Trim();
            entry.DurationMinutes = form.DurationMinutes;
            entry.Calories = form.Calories;
            entry.DistanceKm = form.DistanceKm;

            await _context.SaveChangesAsync();
            return true;
        }

        // DELETE
        public async Task<bool> DeleteAsync(int entryId, int userProfileId)
        {
            var entry = await _context.TrainingEntries
                .FirstOrDefaultAsync(e =>
                    e.Id == entryId &&
                    _context.TrainingDiaries.Any(d => d.Id == e.TrainingDiaryId && d.UserProfileId == userProfileId));

            if (entry == null) return false;

            _context.TrainingEntries.Remove(entry);
            await _context.SaveChangesAsync();
            return true;
        }

        // dropdown: моите дневници
        public async Task<List<(int Id, string Text)>> GetMyDiarySelectItemsAsync(int userProfileId)
        {
            var diaries = await _context.TrainingDiaries
                .AsNoTracking()
                .Where(d => d.UserProfileId == userProfileId)
                .OrderByDescending(d => d.Date)
                .Select(d => new { d.Id, d.Date })
                .ToListAsync();

            return diaries
                .Select(d => (d.Id, d.Date.ToString("dd.MM.yyyy")))
                .ToList();
        }
    }
}
